"""
world_model.py — v0 world-model format.

Implements exactly what four ERS cycles committed on 2026-07-14. Nothing here is
invented: every construct traces to a gated commit, and every limit the falsifiers
found is enforced or named rather than papered over.

  wm_collision_primitive_gate.json  (ans_a) — AT-MOST-ONE-OF collision primitive
  world_model_format_gate.json      (ans_b) — channel-licensed propagation
  wm_format_complete_gate.json      (ans)   — fact format: observed_at/source/volatility
  wm_staleness_gate.json            (ans)   — staleness (superseded in part by the above)

WHAT THIS IS NOT (per the falsifiers, all survived only in narrowed form):
  - NOT a truth oracle. Checks consistency against what was ASSERTED, never truth.
    A false-but-consistent fact passes. (worldmodel_transplant_gate)
  - Does NOT prevent contamination. A wrongly-declared channel or a wrongly-declared
    at-most-one-of set propagates/collides falsely. It makes the error EXPLICIT and
    ATTRIBUTABLE, not impossible. (world_model_format_gate, chk_falsify_b)
  - Does NOT prevent stale facts. Tracks staleness RISK. "Not stale" means "not yet
    due for re-check", never "currently true". (wm_format_complete_gate, chk_falsify_ans)
  - Does NOT catch FRAME/SCOPE overreach at all. That was the other half of the live
    2026-07-14 failure and it remains uncovered here. (wm_staleness_gate, chk_live_case)
  - Silence is not consistency. A claim passes either because it is consistent OR
    because the model is too sparse to disagree; this cannot tell them apart.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum


# ===========================================================================
# FACT FORMAT — wm_format_complete_gate.json (committed: ans)
# ===========================================================================

class Source(Enum):
    """WHO OBSERVED — not who is authoritative about current state.

    Falsifier-forced narrowing (chk_falsify_ans): self-action is fresh-by-
    construction ONLY for the reasoner's own INTERNAL state. "I wrote file X" is
    self-authored, but an external agent can delete X afterwards — the ACT
    happened, the EFFECT may not persist. So self-authored facts about EXTERNAL
    state decay exactly like external observations.
    """
    SELF_INTERNAL = "self-internal"      # reasoner's own internal state: fresh
    SELF_EXTERNAL = "self-external"      # reasoner acted on the world: DECAYS
    EXTERNAL = "external-observation"    # observed the world: DECAYS


class Volatility(Enum):
    """BINARY, not three-class.

    Falsifier-forced narrowing (chk_falsify_cand): the original immutable|slow|
    volatile scheme was FALSIFIED — 'slow' and 'volatile' behave identically
    under the predicate (both re-verify), so the distinction was never
    load-bearing. Collapsed to binary, which keeps the whole saving (no
    perpetual re-verification of things that cannot change) while dropping most
    of the misclassification surface.
    """
    IMMUTABLE = "immutable"   # cannot change: never re-verify
    MUTABLE = "mutable"       # can change: re-verify across a pass boundary


@dataclass(frozen=True)
class Fact:
    """A proposition plus its observation metadata. All three fields MANDATORY —
    that is the point. A fact without them silently claims to be eternally true,
    which is what made the 2026-07-14 staleness failure undetectable."""
    prop: str                  # the proposition, e.g. "files at work_files/"
    observed_at: int           # PASS INDEX when established (not clock time)
    source: Source
    volatility: Volatility

    def needs_reverify(self, current_pass: int) -> bool:
        """The staleness predicate. Three field lookups and a boolean — depth-0,
        nothing derived (o_depth0).

        NOTE: 'pass' here is an integer index. Its BOUNDARY is defined outside
        this module and was NOT gated — Sven's resolution in conversation was
        that the bounce IS the boundary (completion or ceiling), and that this is
        about completion, not freshness. Recorded as ungated.
        """
        if self.source is Source.SELF_INTERNAL:
            return False                      # own internal state: fresh
        if self.volatility is Volatility.IMMUTABLE:
            return False                      # cannot change: never re-verify
        return self.observed_at < current_pass


# ===========================================================================
# COLLISION PRIMITIVE — wm_collision_primitive_gate.json (committed: ans_a)
# ===========================================================================

class Origin(Enum):
    """The origin tag — gate-mandated, does NO checking work.

    Falsifier-forced addition (chk_falsify_cand): the unified at-most-one-of form
    is CORRECT but LOSSY ON PROVENANCE. at_most_one_of({bob-is-mammal,
    bob-is-reptile}) cannot tell you whether that set is a partition (extends to
    new members automatically) or a hand-enumerated pair (does not). Fix was NOT
    to un-collapse into five property types, but to keep one checking form plus
    a non-checking origin tag.
    """
    PARTITION = "partition"              # induced by an equivalence relation; generalizes
    ENUMERATED_PAIR = "enumerated-pair"  # hand-listed; does NOT generalize


@dataclass(frozen=True)
class AtMostOneOf:
    """THE single collision primitive. Subsumes all five catch-types:

      functional slot      at_most_one_of({birthplace=Berlin, birthplace=Paris, ...})
      dimension-exclusion  at_most_one_of({solid, liquid, gas})           [PARTITION]
      category disjoint    at_most_one_of({is-a mammal, is-a reptile})    [PARTITION]
      antisymmetry         at_most_one_of({a>b, b>a})
      irreflexivity        at_most_one_of({a>a})  <- degenerate 1-element: at most zero

    Depth-0: membership lookup over asserted literals. Nothing derived. This is
    why alternative (b), a description-logic engine, was rejected — it needs
    closure and violates o_depth0.

    LIMIT (f_no_totality): cannot express 'exactly one'. It detects collisions;
    it cannot force a slot to be filled. It is NOT a completeness constraint
    language.
    """
    name: str
    members: frozenset[str]
    origin: Origin

    def violated_by(self, asserted: set[str]) -> set[str]:
        """Return the colliding members if >1 of this set is asserted.

        Degenerate 1-element case (irreflexivity) means 'at most zero' — the
        member must not be asserted at all.
        """
        hits = self.members & asserted
        if len(self.members) == 1:
            return hits                      # irreflexive: any hit is a violation
        return hits if len(hits) > 1 else set()


# ===========================================================================
# PROPAGATION LICENSING — world_model_format_gate.json (committed: ans_b)
# ===========================================================================

class Direction(Enum):
    FORWARD = "forward"    # along the relation: src -> dst
    BACKWARD = "backward"  # against it: dst -> src (e.g. mass accumulates up part-of)


@dataclass(frozen=True)
class Channel:
    """A LICENSE for one predicate to travel one relation in one direction.

    The whole rule (ans_b): propagation is licensed per (predicate, relation,
    direction) by EXPLICIT DECLARATION. Undeclared channels do not propagate.

    Why declare-to-travel rather than transitive-with-exceptions: the set of
    predicates that do NOT travel a relation is unbounded and cannot be
    enumerated (f_exceptions_unbounded); the set that DO is small. Inverting the
    default makes the unbounded set INERT rather than exceptional — the same
    structural-refusal discipline as ERS, where the malformed case is unwritable
    rather than detected.

    A relation's own transitivity is ITSELF just a declared channel:
    Channel("part-of", "part-of", FORWARD). There is no general
    'relations are transitive' rule and no exception mechanism.

    LIMIT (chk_falsify_b): a WRONGLY declared channel (colour travels down
    part-of) propagates falsehood soundly-by-construction. This cannot detect a
    bad declaration. Contamination is RELOCATED to the declaration act — where
    it is explicit, attributable and hand-checkable — not eliminated.
    """
    predicate: str
    relation: str
    direction: Direction


@dataclass(frozen=True)
class Edge:
    src: str
    relation: str
    dst: str


@dataclass
class WorldModel:
    facts: dict[str, Fact] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    constraints: list[AtMostOneOf] = field(default_factory=list)
    channels: set[Channel] = field(default_factory=set)
    current_pass: int = 0

    # --- writes -----------------------------------------------------------
    def declare(self, c: AtMostOneOf) -> None:
        self.constraints.append(c)

    def license(self, ch: Channel) -> None:
        self.channels.add(ch)

    def assert_fact(self, f: Fact) -> list[str]:
        """Write a fact. Returns a list of REFUSAL REASONS; empty list == admitted.

        This is the format-enforcement point: a write that collides with a
        declared at-most-one-of set is REFUSED, not recorded-and-flagged.
        """
        colliding = []
        for c in self.constraints:
            hits = c.violated_by(set(self.facts) | {f.prop})
            if f.prop in hits and hits:
                others = sorted(hits - {f.prop})
                if len(c.members) == 1:
                    colliding.append(
                        f"'{f.prop}' violates {c.name} (irreflexive: at most zero)")
                elif others:
                    colliding.append(
                        f"'{f.prop}' collides with {others} under {c.name} "
                        f"[{c.origin.value}]")
        if colliding:
            return colliding
        self.facts[f.prop] = f
        return []

    # --- reads ------------------------------------------------------------
    def stale(self) -> list[Fact]:
        """Facts due for re-verification at the current pass. Depth-0."""
        return [f for f in self.facts.values()
                if f.needs_reverify(self.current_pass)]

    def propagate(self, predicate: str, holder: str) -> list[tuple[str, str]]:
        """Derive where `predicate` legitimately travels from `holder`.

        ONLY along declared channels. An undeclared (predicate, relation,
        direction) is INERT — it does not propagate, and that silence is the
        safety property (f_exceptions_unbounded).

        Returns [(target_concept, via_relation)]. One hop: multi-hop closure is
        depth and stays deferred.
        """
        out: list[tuple[str, str]] = []
        for ch in self.channels:
            if ch.predicate != predicate:
                continue
            for e in self.edges:
                if e.relation != ch.relation:
                    continue
                if ch.direction is Direction.FORWARD and e.src == holder:
                    out.append((e.dst, e.relation))
                elif ch.direction is Direction.BACKWARD and e.dst == holder:
                    out.append((e.src, e.relation))
        return out

    def advance_pass(self) -> int:
        """A pass boundary. NOT GATED — Sven's resolution was that the bounce IS
        the boundary (completion or ceiling), and that it is about completion,
        not freshness. Recorded here as a caller-driven index, deliberately not
        given a principled internal definition."""
        self.current_pass += 1
        return self.current_pass

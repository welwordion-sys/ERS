# v0 world-model format — first build

Implements the four ERS commits from 2026-07-14. Nothing invented: every
construct traces to a gated cycle, and every falsifier-found limit is either
enforced or demonstrated rather than papered over.

    python3 wm_test.py

## Status: BUILT AND RUN — but this is not validation

The gates tested ARGUMENTS. This is the first execution. It confirms the format
behaves as the arguments claimed; it does NOT confirm the arguments were right
about anything outside these hand-built cases. First real test is running it
against Sven's ground-truth stock, which does not exist yet.

## What ran

CASE 1 — the live 2026-07-14 failure, caught. 'gate files absent from repo'
observed at pass 0, external + mutable; after two natural renewals (Sven
answering), stale() fires -> re-verify before asserting. The error that actually
happened is caught by the format that came out of diagnosing it.

CASE 2 — the falsifier's narrowing holds in code. 'I wrote /tmp/out.zip'
(self-external) DECAYS; 'I decided to archive' (self-internal) does not. The act
happened; the effect may not persist.

CASE 3 — one primitive, five catch-types, all firing:
dimension-value exclusion, category disjointness, antisymmetry, irreflexivity
(degenerate at-most-zero), cross-dimension pair. Origin tag distinguishes
partition from enumerated-pair without doing any checking work.

CASE 4 — channel licensing. part-of travels part-of (declared) -> propagates.
colour travels part-of (undeclared) -> INERT, wheel does not become red. Then a
WRONG declaration is added and contamination flows — demonstrating chk_falsify_b:
the mechanism cannot detect a bad declaration, it only makes it attributable.

CASE 5 — the ceilings, demonstrated rather than asserted:
  - 'bob is-a fish' ADMITTED. Not a truth oracle.
  - 'is-a reptile' admitted into a model lacking 'is-a mammal' — passed because
    the model is too SPARSE to disagree. Silence is not consistency.
  - no totality: cannot force a slot to be filled.
  - frame overreach: UNCOVERED ENTIRELY.

## Known-open
- 'pass' boundary is caller-driven and UNGATED (Sven: the bounce IS the boundary;
  it is about completion, not freshness).
- Multi-hop closure is deferred (depth). propagate() is one hop.
- No ground-truth stock exists. Every fact here is hand-built for the test.

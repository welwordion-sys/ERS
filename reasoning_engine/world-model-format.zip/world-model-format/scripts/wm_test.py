"""
wm_test.py — first contact between the gated format and execution.

Every gate on 2026-07-14 tested ARGUMENTS, not behaviour. This runs the format.
The headline case is the LIVE FAILURE: Claude asserted 'gate files not pushed'
from a 404 at the wrong path, while Sven had in fact pushed them.
"""

from world_model import (
    WorldModel, Fact, Source, Volatility,
    AtMostOneOf, Origin, Channel, Direction, Edge,
)


def case_live_failure():
    print("=" * 70)
    print("CASE 1 — the actual 2026-07-14 failure")
    print("=" * 70)
    wm = WorldModel()

    # Pass 0: Claude checks the repo, sees a 404 at reasoning_engine/.
    wm.assert_fact(Fact("gate files absent from repo", observed_at=0,
                        source=Source.EXTERNAL, volatility=Volatility.MUTABLE))
    print("pass 0: observed 'gate files absent from repo' (external, mutable)")

    # Sven answers several times. Each is a natural renewal -> pass boundary.
    wm.advance_pass(); wm.advance_pass()
    print(f"pass advanced to {wm.current_pass} (Sven answered twice)")

    stale = wm.stale()
    print(f"\nstale() -> {[f.prop for f in stale]}")
    if stale:
        print("  VERDICT: re-verify BEFORE asserting. The check FIRES.")
        print("  This is the error that actually happened, caught.")
    else:
        print("  VERDICT: no re-verify. Format FAILED to catch its motivating case.")

    # Contrast: a fact that should NOT trigger re-verification.
    wm.assert_fact(Fact("setter is v0.6", observed_at=0,
                        source=Source.EXTERNAL, volatility=Volatility.IMMUTABLE))
    wm.assert_fact(Fact("I ran 5 gate cycles", observed_at=0,
                        source=Source.SELF_INTERNAL, volatility=Volatility.MUTABLE))
    print(f"\nafter adding an immutable external + a self-internal fact:")
    print(f"  stale() -> {[f.prop for f in wm.stale()]}")
    print("  (immutable never re-verifies; own internal state is fresh)")


def case_self_external():
    print("\n" + "=" * 70)
    print("CASE 2 — the falsifier's narrowing: self-action is NOT free")
    print("=" * 70)
    wm = WorldModel()
    wm.assert_fact(Fact("I wrote /tmp/out.zip", observed_at=0,
                        source=Source.SELF_EXTERNAL, volatility=Volatility.MUTABLE))
    wm.assert_fact(Fact("I decided to archive the engine", observed_at=0,
                        source=Source.SELF_INTERNAL, volatility=Volatility.MUTABLE))
    wm.advance_pass()
    stale = [f.prop for f in wm.stale()]
    print(f"stale() -> {stale}")
    print("  'I wrote the file' DECAYS — the act happened, the effect may not persist.")
    print("  'I decided X' does not — that IS internal state.")
    print(f"  correct: {stale == ['I wrote /tmp/out.zip']}")


def case_collisions():
    print("\n" + "=" * 70)
    print("CASE 3 — at-most-one-of subsumes all five catch-types")
    print("=" * 70)
    wm = WorldModel()

    wm.declare(AtMostOneOf("state-of-matter",
                           frozenset({"solid", "liquid", "gas"}), Origin.PARTITION))
    wm.declare(AtMostOneOf("mammal-xor-reptile",
                           frozenset({"is-a mammal", "is-a reptile"}), Origin.PARTITION))
    wm.declare(AtMostOneOf("taller-antisym",
                           frozenset({"a>b", "b>a"}), Origin.ENUMERATED_PAIR))
    wm.declare(AtMostOneOf("taller-irreflexive",
                           frozenset({"a>a"}), Origin.ENUMERATED_PAIR))
    wm.declare(AtMostOneOf("transparent-xor-dark",
                           frozenset({"transparent", "dark"}), Origin.ENUMERATED_PAIR))

    trials = [
        ("solid", "dimension-value exclusion", True),
        ("gas", "dimension-value exclusion", False),
        ("is-a mammal", "category disjointness", True),
        ("is-a reptile", "category disjointness", False),
        ("a>b", "antisymmetry", True),
        ("b>a", "antisymmetry", False),
        ("a>a", "irreflexivity (degenerate)", False),
        ("transparent", "cross-dimension pair", True),
        ("dark", "cross-dimension pair", False),
    ]
    for prop, kind, should_pass in trials:
        refusals = wm.assert_fact(Fact(prop, 0, Source.EXTERNAL, Volatility.MUTABLE))
        ok = (not refusals) == should_pass
        mark = "OK " if ok else "!! "
        if refusals:
            print(f"  {mark}REFUSED  {prop:16} [{kind}]")
            for r in refusals:
                print(f"           {r}")
        else:
            print(f"  {mark}admitted {prop:16} [{kind}]")


def case_channels():
    print("\n" + "=" * 70)
    print("CASE 4 — channel licensing: the car/wheel contamination")
    print("=" * 70)
    wm = WorldModel()
    wm.edges += [Edge("wheel", "part-of", "car"), Edge("car", "part-of", "garage")]

    # Declare ONLY part-of travelling itself. colour is NOT declared.
    wm.license(Channel("part-of", "part-of", Direction.FORWARD))

    print("declared channels: part-of travels part-of (forward)")
    print("NOT declared: colour travels part-of\n")

    print(f"  propagate('part-of', 'wheel')  -> {wm.propagate('part-of', 'wheel')}")
    print("    part-of chains: wheel is part-of car. SOUND.")
    print(f"  propagate('colour', 'car')     -> {wm.propagate('colour', 'car')}")
    print("    colour does NOT travel down part-of. The wheel does not become red.")
    print("    The undeclared channel is INERT — that silence is the safety property.")

    # Now show the falsifier's point: a WRONG declaration contaminates.
    print("\n  now WRONGLY declare colour travels part-of (backward: car->wheel):")
    wm.license(Channel("colour", "part-of", Direction.BACKWARD))
    print(f"  propagate('colour', 'car')     -> {wm.propagate('colour', 'car')}")
    print("    Now it DOES propagate. The mechanism cannot detect a bad declaration.")
    print("    Contamination is RELOCATED to the declaration act, not eliminated.")


def case_ceiling():
    print("\n" + "=" * 70)
    print("CASE 5 — the ceilings, demonstrated not asserted")
    print("=" * 70)
    wm = WorldModel()
    wm.declare(AtMostOneOf("mammal-xor-reptile",
                           frozenset({"is-a mammal", "is-a reptile"}), Origin.PARTITION))

    # False but consistent -> passes. NOT a truth oracle.
    r = wm.assert_fact(Fact("bob is-a fish", 0, Source.EXTERNAL, Volatility.MUTABLE))
    print(f"  assert 'bob is-a fish' (false, but nothing contradicts) -> "
          f"{'ADMITTED' if not r else 'refused'}")
    print("    Not a truth oracle. False-but-consistent passes.")

    # Silence is not consistency.
    r = wm.assert_fact(Fact("is-a reptile", 0, Source.EXTERNAL, Volatility.MUTABLE))
    print(f"  assert 'is-a reptile' into a model with no 'is-a mammal' -> "
          f"{'ADMITTED' if not r else 'refused'}")
    print("    Passed because the model is too SPARSE to disagree, not because")
    print("    it is consistent. Silence is not consistency.")

    # No totality.
    print("  no way to express 'bob MUST have a category' — at-most-one-of")
    print("    cannot force a slot to be filled (f_no_totality).")

    # Frame overreach — uncovered entirely.
    print("  frame overreach ('404 at one path' -> 'not in the repo'):")
    print("    NOTHING here catches it. Uncovered by the world-model entirely.")


if __name__ == "__main__":
    case_live_failure()
    case_self_external()
    case_collisions()
    case_channels()
    case_ceiling()

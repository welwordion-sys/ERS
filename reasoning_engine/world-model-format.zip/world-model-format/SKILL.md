---
name: world-model-format
description: Track facts with observation provenance (who observed it, when, how volatile), check at-most-one-of collision constraints, and derive licensed propagation across declared relations. Use when a task needs to know whether an asserted fact is stale before treating it as current, catch mutually-exclusive facts (category clashes, functional-slot conflicts, antisymmetry), or determine what a predicate legitimately implies elsewhere in a graph. v0 format from four 2026-07-14 ERS-gated cycles — built and run, NOT yet validated against real data.
---

# World-Model Format (v0)

A small fact-store with three ERS-gated mechanisms: staleness tracking,
collision detection, and licensed propagation. Nothing here is invented —
every construct traces to a specific committed gate cycle (see
`scripts/world_model.py` header for the mapping). Nothing here is validated
beyond the mechanism's own hand-built test cases (`scripts/wm_test.py`) —
there's no ground-truth stock to run it against yet.

## What this actually does

- **`Fact`** — a proposition plus mandatory `observed_at` (pass index, not
  clock time), `source`, `volatility`. `needs_reverify(current_pass)` is the
  staleness predicate: self-internal facts never restale, immutable facts
  never restale, everything else restales once the pass has moved on from
  `observed_at`.
- **`AtMostOneOf`** — one collision primitive subsuming five catch-types
  (functional slot, dimension-exclusion, category-disjointness,
  antisymmetry, irreflexivity-as-at-most-zero). `origin` (partition vs
  enumerated-pair) is a non-checking provenance tag only.
- **`Channel`/`propagate()`** — a predicate travels a relation only if
  explicitly licensed as `(predicate, relation, direction)`. Undeclared =
  inert, not exception-checked. One hop; multi-hop closure is deferred.

## What this does NOT do (say this out loud before using it, don't let it get overclaimed)

- **Not a truth oracle.** Checks consistency against what's asserted, never
  against truth. A false-but-consistent fact is admitted.
- **Doesn't prevent contamination**, only makes it attributable. A wrongly
  declared channel or wrongly declared collision set still propagates or
  admits falsely — it relocates the error to the declaration act, where
  it's at least hand-checkable.
- **Doesn't prevent stale facts**, only tracks staleness *risk*.
  "Not stale" means "not yet due for re-check," never "currently true."
- **Doesn't catch frame/scope overreach at all** — e.g. "404 at one path"
  being over-read as "not in the repo." Entirely uncovered.
- **Can't tell silence from consistency.** A claim can pass because the
  model actually agrees, or because the model is too sparse to disagree —
  indistinguishable from inside the format.
- **No totality.** Can't express "this slot must be filled," only "these
  values collide if more than one is asserted."
- **`advance_pass()`'s pass boundary is caller-driven and deliberately
  ungated** — per Sven, the bounce IS the boundary (completion/ceiling),
  not a freshness clock. Don't invent a principled internal definition for
  it; that was a live design choice, not an oversight.

## When to reach for this

- Before treating a previously-asserted fact (in a KB node, a session
  summary, a prior gate answer) as still current — check `needs_reverify`
  instead of assuming persistence. This is literally what would have caught
  the 2026-07-14 "gate files absent from repo" failure: external + mutable
  facts decay, including facts about your own past actions on external
  state (writing a file doesn't keep it there).
- When a set of asserted facts might be mutually exclusive and you want
  that made structural rather than remembered — declare an `AtMostOneOf`
  rather than eyeballing for contradictions each time.
- When deciding whether a property legitimately extends across a relation
  (e.g. does "colour" travel "part-of"?) — license it explicitly rather
  than assuming transitivity, and treat an unlicensed case as inert, not
  as a gap to paper over.

## When NOT to reach for this

- Don't use it as a consistency/truth checker for a KB write generally —
  that's `kb-write-routine`'s cold-read gate and, for GATE-tier claims,
  `ers-gate`. This format only tracks the narrow staleness/collision/
  propagation slice, and admits plenty a human would catch (see limits
  above).
- Don't treat a clean `wm_test.py` run as validation of the design. It
  confirms the code does what the gated arguments claimed on hand-built
  cases. It says nothing about real data yet.

## Usage

```python
from world_model import WorldModel, Fact, Source, Volatility, AtMostOneOf, Origin, Channel, Direction, Edge

wm = WorldModel()
wm.declare(AtMostOneOf("category", frozenset({"is-a mammal", "is-a reptile"}), Origin.PARTITION))
wm.license(Channel("part-of", "part-of", Direction.FORWARD))

wm.assert_fact(Fact("gate files pushed to work_files/", observed_at=0,
                     source=Source.SELF_EXTERNAL, volatility=Volatility.MUTABLE))
# ... passes advance ...
wm.advance_pass()
stale = wm.stale()   # re-check before asserting these are still true
```

See `scripts/wm_test.py` for all five worked cases (staleness catch,
self-external decay, collision primitive, channel licensing +
mis-declaration, and the five demonstrated ceilings) if a concrete usage
shape is needed.
